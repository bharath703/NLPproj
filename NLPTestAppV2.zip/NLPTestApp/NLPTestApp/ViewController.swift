//
//  ViewController.swift
//  NLPTestApp
//
//  Created by Bharath on 09/12/18.
//  Copyright © 2018 TestCompany. All rights reserved.
//

import UIKit
import Foundation


class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableViewObj: UITableView!
    
    @IBOutlet weak var textField: UITextField!
    
    @IBOutlet weak var tableViewStem: UITableView!
    
    var wordList = [String]()
    var stemList = [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.tableViewObj.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        self.tableViewStem.register(UITableViewCell.self, forCellReuseIdentifier: "Cell2")
        
    }
    
    func NLPTestFunct()
    {
        var text = ""
        text =  textField.text ?? " "
        
        
        let tagger = NSLinguisticTagger(tagSchemes: [.tokenType, .language, .lexicalClass, .nameType, .lemma], options: 0)
        tagger.string = text
        
        let range = NSRange(location: 0, length: text.utf16.count)
        let options: NSLinguisticTagger.Options = [.omitPunctuation, .omitWhitespace, .joinNames]
        
        tagger.enumerateTags(in: range, unit: .word, scheme: .lexicalClass, options: options) { tag, tokenRange, _ in
            if let tag = tag {
                let word = (text as NSString).substring(with: tokenRange)
                let wordText = "\(word): \(tag.rawValue)"

                wordList.append(wordText)
                print(wordText)
            }
        }
       
    }
    
    func lemmatization()
    {
        var text = ""
        text =  textField.text ?? " "
        
        
        let tagger = NSLinguisticTagger(tagSchemes:[.tokenType, .language, .lexicalClass, .nameType, .lemma], options: 0)
        let options: NSLinguisticTagger.Options = [.omitPunctuation, .omitWhitespace, .joinNames]
        tagger.string = text
        
        let range = NSRange(location:0, length: text.utf16.count)
        tagger.enumerateTags(in: range, unit: .word, scheme: .lemma, options: options) { tag, tokenRange, stop in
            if let lemma = tag?.rawValue {
                let word = (text as NSString).substring(with: tokenRange)
                let wordText = "\(word): \(lemma)"
                stemList.append(wordText)
                print(lemma)
            }
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(tableView == tableViewObj)
        {
            return wordList.count
        }
        else if(tableView == tableViewStem)
        {
            return stemList.count
        }
        else
        {
            return 1
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if(tableView == tableViewObj)
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Cell")!
            
            let text = wordList[indexPath.row]
            
            cell.textLabel?.text = text
            
            return cell
        }
        else if(tableView == tableViewStem)
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Cell2")!
            
            let text = stemList[indexPath.row]
            
            cell.textLabel?.text = text
            
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell")!
            return cell
        }
        
        
    }
    

    
    
    @IBAction func analyzeButtonAction(_ sender: Any)
    {
        if(textField.text!.isEmpty)
        {
            let alert = UIAlertController(title: "Alert", message: "Text field cannot be empty", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                switch action.style{
                case .default:
                    print("default")
                    
                case .cancel:
                    print("cancel")
                    
                case .destructive:
                    print("destructive")
                    
                    
                }}))
            self.present(alert, animated: true, completion: nil)
        }
        else
        {
            
            textField.resignFirstResponder()
            NLPTestFunct()
            lemmatization()
            tableViewObj.numberOfRows(inSection: wordList.count)
            tableViewStem.numberOfRows(inSection: stemList.count)
            tableViewObj.reloadData()
            tableViewStem.reloadData()

        }
        
        
    }


    @IBAction func clearButtonAction(_ sender: Any)
    {
        textField.text = ""
        wordList.removeAll()
        stemList.removeAll()
        tableViewObj.reloadData()
        tableViewStem.reloadData()
    }
}

